﻿using AttendanceSergeElio.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace AttendanceSergeElio.Controllers
{
    public class ReportsController : Controller
    {
        private readonly ApplicationDbContext _context;  // Define a private field for the DbContext

        // Inject ApplicationDbContext into the constructor
        public ReportsController(ApplicationDbContext context)
        {
            _context = context;  // Initialize the _context field
        }

        public async Task<IActionResult> CreateReport(ReportParameters parameters)
        {
            var query = _context.Attendances.Include(a => a.Session).Include(a => a.User).AsQueryable();

            if (parameters.StartDate.HasValue)
                query = query.Where(a => a.Session.Date >= parameters.StartDate.Value);
            if (parameters.EndDate.HasValue)
                query = query.Where(a => a.Session.Date <= parameters.EndDate.Value);
            if (parameters.SessionId.HasValue)
                query = query.Where(a => a.SessionId == parameters.SessionId.Value);
            if (!string.IsNullOrEmpty(parameters.UserId))
                query = query.Where(a => a.UserId == parameters.UserId);

            var results = await query.ToListAsync();

            return View("ReportResults", results);  // Ensure you have a ReportResults view to display this data
        }

        public IActionResult Index()
        {
            return View();
        }
    }
}
