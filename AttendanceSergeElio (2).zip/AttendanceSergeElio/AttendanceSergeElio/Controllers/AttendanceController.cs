﻿using Microsoft.AspNetCore.Mvc;
using AttendanceSergeElio.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Authorization;

[Authorize(Roles = "Admin,Teacher")]
public class AttendanceController : Controller
{
    private readonly ApplicationDbContext _context;

    public AttendanceController(ApplicationDbContext context)
    {
        _context = context;
    }

    // GET: Attendance
    public async Task<IActionResult> Index()
    {
        var attendances = await _context.Attendances.Include(a => a.Session).Include(a => a.User).ToListAsync();
        return View(attendances);
    }

    // GET: Attendance/Create
    public IActionResult Create()
    {
        return View();
    }

    // POST: Attendance/Create
    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Create([Bind("SessionId,UserId,IsPresent")] Attendance attendance)
    {
        if (ModelState.IsValid)
        {
            _context.Add(attendance);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }
        return View(attendance);
    }
}
