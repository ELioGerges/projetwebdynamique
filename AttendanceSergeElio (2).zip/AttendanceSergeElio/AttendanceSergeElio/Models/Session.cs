﻿using System;
using System.ComponentModel.DataAnnotations;
namespace AttendanceSergeElio.Models
{
    public class Session
    {
        public int SessionId { get; set; }
        public DateTime Date { get; set; }
        public string Time { get; set; }
        public string Location { get; set; }
        public string Purpose { get; set; }
    }
}




