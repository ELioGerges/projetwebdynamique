﻿namespace AttendanceSergeElio.Models
{
    public class ReportParameters
    {
        public DateTime? StartDate { get; set; }
        public DateTime? EndDate { get; set; }
        public int? SessionId { get; set; }
        public string UserId { get; set; }
    }
}
